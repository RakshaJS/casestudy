import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { ProductserviceService } from 'src/app/service/productservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:Product[];
  config: any; 
  collection = [];

  constructor(private route: ActivatedRoute,private productservices: ProductserviceService, private router:Router) {
    this.config = {
      currentPage: 1,
      itemsPerPage:5
  };
  
  this.route.queryParamMap
        .map(params => params.get('page'))
        .subscribe(page => this.config.currentPage= page);
        for (let i = 1; i <= 100; i++) {
          this.collection.push(`item ${i}`);
          }
          
          }
          
          pageChange(newPage: number) {
          this.router.navigate(['products'], { queryParams: { page: newPage }});
            
   }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
this.productservices.getproducts().subscribe(data=>{
  this.products= data;
})
    }
    else{
      this.router.navigate(['/login']);
    }
  }
  deleteProduct(product:Product):void{
    let result=confirm("Do you really want to delete the user");
    if(result){
this.productservices.deleteProducts(product.id).subscribe(data=>{
  this.products = this.products.filter(u=>u!==product)
});
    }
  }
  addProduct():void{
this.router.navigate(['/addproduct']);
  }
  editProduct(product:Product):void{
    localStorage.removeItem("editProductId");
    localStorage.setItem("editProductId", product.id.toString());
    this.router.navigate(['/editproduct']);
  }
// logOutUser():void{
//   if(localStorage.getItem("username")!=null){
// localStorage.removeItem("username");
// this.router.navigate(['/login']);
//   }
// }


}
