import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})

export class ProductserviceService {

baseurl: string= "http://localhost:3000/products";

  constructor(private http:HttpClient) { }
createProduct(products: Product){

  return this.http.post(this.baseurl,products);
}
  updateProduct(products: Product){
  return this.http.put(this.baseurl+'/'+products.id,products);
 }
deleteProducts(id:number){
return this.http.delete(this.baseurl+"/"+id);
}
getProductById(id:number){
  return this.http.get<Product>(this.baseurl+"/"+id);
}
  getproducts(){
    return this.http.get<Product[]>(this.baseurl)
  }
}
